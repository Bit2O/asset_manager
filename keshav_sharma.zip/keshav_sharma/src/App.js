import React from 'react';
import './App.css';
import './base.css';

// import seed data func
import { seedHunderedTempData, category, labels } from './seed.js'


function updatingLocalStorage(key, val) {
    window.localStorage.setItem(key, JSON.stringify(val))
}

function getFromLocalStorage(key) {
    return JSON.parse(window.localStorage.getItem(key))
}

class App extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            assets: [],
            activeAssets: [],
            andFilters: [],
            activeAndFilters: [],
            activeOrFilters: [],
            orFilters: [],
            categories: [],
            activeCat: "",
            summary: {}
            // labels: []
        }
    }

    componentDidMount() {
        this.seedData()
        this.setState({
            assets: getFromLocalStorage("assets"),
            categories: category,
            andFilters: labels,
            orFilters: labels,
            activeCat: category[0],
            activeAssets: this.calculateActiveAsses(category[0])
        })
        this.calculateSummary(this.calculateActiveAsses(category[0]))
    }

    calculateActiveAsses = (cat) => {
        const assets = getFromLocalStorage("assets")
        let categoryWiseAssets = assets.filter(a => a.category === cat)
        return categoryWiseAssets
    }

    seedData = () => {
        const data = seedHunderedTempData(100)
        const categories = category
        window.localStorage.setItem("assets", JSON.stringify(data))
        window.localStorage.setItem("category", JSON.stringify(categories))
        window.localStorage.setItem("labels", JSON.stringify(labels))
        this.setState({
            assets: getFromLocalStorage("assets"),
            categories: category,
            andFilters: labels,
            orFilters: labels,
            activeCat: category[0],
            activeAssets: this.calculateActiveAsses(category[0])
        })
        this.calculateSummary(this.calculateActiveAsses(category[0]))
    }


    updateActiveCat = cat => {
        this.setState({
            activeCat: cat,
            activeAssets: this.calculateActiveAsses(cat),
            andFilters: labels,
            orFilters: labels,
            activeAndFilters: [],
            activeOrFilters: []
        })
        this.calculateSummary(this.calculateActiveAsses(cat))
    }


    updateOrAndFilters = (lab, op = 'add') => {

        if (op === 'add') {
            const { orFilters, andFilters } = this.state

            let newAndFilter = andFilters.slice()
            let newOrFilter = orFilters.slice()

            if (newAndFilter.indexOf(lab) >= 0) {
                newAndFilter.splice(newAndFilter.indexOf(lab), 1)
                this.setState({
                    andFilters: newAndFilter
                })
            }

            if (newOrFilter.indexOf(lab) >= 0) {
                newOrFilter.splice(newOrFilter.indexOf(lab), 1)
                this.setState({
                    orFilters: newOrFilter
                })
            }
        } else {
            const { activeOrFilters, activeAndFilters } = this.state

            let newAndFilter = activeAndFilters.slice()
            let newOrFilter = activeOrFilters.slice()

            if (newAndFilter.indexOf(lab) >= 0) {
                newAndFilter.splice(newAndFilter.indexOf(lab), 1)
                this.setState({
                    activeAndFilters: newAndFilter
                }, () => this.applyOrFilters())
            }

            if (newOrFilter.indexOf(lab) >= 0) {
                newOrFilter.splice(newOrFilter.indexOf(lab), 1)
                this.setState({
                    activeOrFilters: newOrFilter
                }, () => this.applyOrFilters())
            }
        }

    }

    updateLabels = lab => {
        const { orFilters, andFilters } = this.state
        let newOrFilter = orFilters.slice()
        let newAndFilter = andFilters.slice()

        this.updateOrAndFilters(lab, 'remove')

        newOrFilter.push(lab)
        newAndFilter.push(lab)
        this.setState({
            orFilters: newOrFilter,
            andFilters: newAndFilter
        })
    }

    addActiveOrFilter = (lab, op = 'add') => {
        if (op === 'add') {
            const { activeOrFilters } = this.state
            let newActiveOrFilter = activeOrFilters.slice()

            this.updateOrAndFilters(lab)

            newActiveOrFilter.push(lab)
            this.setState({
                activeOrFilters: newActiveOrFilter
            }, () => this.applyOrFilters())
        } else {
            this.updateLabels(lab)
        }
    }

    addActiveAndFilter = (lab, op = 'add') => {
        if (op === 'add') {
            const { activeAndFilters } = this.state
            let newActiveAndFilter = activeAndFilters.slice()

            this.updateOrAndFilters(lab)

            newActiveAndFilter.push(lab)
            this.setState({
                activeAndFilters: newActiveAndFilter
            }, () => this.applyOrFilters())
        } else {
            this.updateLabels(lab)
        }
    }

    applyOrFilters = () => {
        const activeAssets = this.calculateActiveAsses(this.state.activeCat)
        const { activeOrFilters } = this.state
        let newAssets = activeAssets.filter((a, i) => {
            for (i = 0; i < activeOrFilters.length; i++) {
                if (a.labels.indexOf(activeOrFilters[i]) >= 0) {
                    return true
                } else {
                    continue
                }
            }
        })
        if (activeOrFilters.length === 0) {
            newAssets = activeAssets
        }
        this.setState({
            activeAssets: newAssets
        })
        this.applyAndFilters(newAssets)
    }

    applyAndFilters = activeAssets => {
        const { activeAndFilters } = this.state

        let newAssets = activeAssets.filter(asset => activeAndFilters.every(filter => asset.labels.some(label => label === filter)))

        console.log("assets and filters: ", activeAssets, newAssets, activeAndFilters)
        this.setState({
            activeAssets: newAssets
        })
        this.calculateSummary(newAssets)
    }


    calculateSummary = assets => {
        let summary = assets.reduce((summary, asset, i) => {
            let totalArea = summary.totalArea ? summary.totalArea + asset.sqFootArea : asset.sqFootArea
            let totalIncome = summary.totalIncome ? summary.totalIncome + asset.incomeFromAsset : asset.incomeFromAsset
            console.log("assets income: ", assets, asset, summary, totalArea, totalIncome)
            return {
                totalArea,
                totalIncome
            }
        }, {})
        summary.totalAssets = assets.length
        this.setState({
            summary
        })
    }


    render() {
        let {
            assets,
            categories,
            andFilters,
            orFilters,
            activeCat,
            activeAndFilters,
            activeOrFilters,
            activeAssets
        } = this.state

        console.log("assets: ", activeAssets)

        return (
            <div>
                {
                    true
                    &&
                    <section className="author-archive">
                        <div className="container">
                            <div className="row">
                                <h1 className="ten columns">All My Assets</h1>
                                <button onClick={() => this.seedData()} className="two columns">Seed data</button>
                            </div>

                            <div className="row">
                                <strong className="two columns">Categories: </strong>
                                <ol className="ten columns filters">
                                    {
                                        categories.map(c => {
                                            return (
                                                <li key={c} onClick={() => this.updateActiveCat(c)}>
                                                    <label className={`${activeCat == c ? 'active' : ''}`} key={c}>{c}</label>
                                                </li>
                                            )
                                        })
                                    }
                                </ol>
                            </div>
                            <div className="row">
                                <div className="five columns">
                                    <div className="row">
                                        <strong className="two columns">Any of: </strong>
                                        <ol className="five columns">
                                            {
                                                orFilters.map(c => {
                                                    return (
                                                        <li key={c} onClick={() => this.addActiveOrFilter(c)}>
                                                            <label key={c}>{c}</label>
                                                        </li>
                                                    )
                                                })
                                            }
                                        </ol>
                                        <ol className="five columns">
                                            {
                                                activeOrFilters.map(c => {
                                                    return (
                                                        <li key={c}>
                                                            <label onClick={() => this.addActiveOrFilter(c, 'remove')} className={`active`} key={c}>{c}</label>
                                                        </li>
                                                    )
                                                })
                                            }
                                        </ol>
                                    </div>
                                    <div className="row">
                                        <strong className="two columns">All of: </strong>
                                        <ol className="five columns">
                                            {
                                                andFilters.map(c => {
                                                    return (
                                                        <li key={c} onClick={() => this.addActiveAndFilter(c)}>
                                                            <label key={c}>{c}</label>
                                                        </li>
                                                    )
                                                })
                                            }
                                        </ol>
                                        <ol className="five columns">
                                            {
                                                activeAndFilters.map(c => {
                                                    return (
                                                        <li key={c}>
                                                            <label onClick={() => this.addActiveAndFilter(c, 'remove')} className={`active`} key={c}>{c}</label>
                                                        </li>
                                                    )
                                                })
                                            }
                                        </ol>
                                    </div>

                                </div>
                                <article className="seven columns">
                                    <p>
                                        Summary...
                                </p>
                                    <p>
                                        Total Income: ${this.state.summary.totalIncome}
                                    </p>
                                    <p>
                                        Total Area: {this.state.summary.totalArea} sqft
                                </p>
                                    <p>Total Assets: {this.state.summary.totalAssets}</p>
                                </article>
                            </div>

                                <ol className="posts">
                                    {
                                        activeAssets.map(a => {
                                            return (
                                                <li key={a.id} className="post">
                                                    <article>
                                                        <figure>
                                                            <img src="https://via.placeholder.com/300" alt="" />
                                                            <figcaption>
                                                                <ol className="post-categories">
                                                                    {
                                                                        a.labels.map(l => {
                                                                            return (
                                                                                <li key={l}>
                                                                                    <a href="">{l}</a>
                                                                                </li>
                                                                            )
                                                                        })
                                                                    }
                                                                </ol>
                                                                <h2 className="post-title">
                                                                    {a.name}
                                                                </h2>
                                                                <span>category: {a.category}</span>
                                                                <p>Income: ${a.incomeFromAsset}</p>
                                                                <p>Area of Property: {a.sqFootArea} sqft</p>
                                                            </figcaption>
                                                        </figure>
                                                    </article>
                                                </li>
                                            )
                                        })
                                    }
                                </ol>
                            </div>
                    </section>
                        }
                <footer>
                            <div className="container">
                                <small>done by keshav sharma
                        </small>
                            </div>
                        </footer>
            </div>
        )
                }

}

export default App;
