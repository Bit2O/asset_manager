var faker = require('faker');

const assetObj = {
    id: faker.random.uuid,
    name: faker.company.companyName,
    category: "",
    incomeFromAsset: 1234,
    sqFootArea: 233,
    labels: []
}

const category = ["shop", "bridge", "mall", "airport"]
const labels = ['new', 'bangalore', 'mid-income', 'watchlist', 'high-football', 'low-profit']

function randomInteger(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

function getLabels() {
    // get randomly how many labels should we add
    let selectLabelsFrom = [...labels]
    let labelsArr = []
    const noOfRandomLabels = randomInteger(1, 6)
    for (let i = 0; i < noOfRandomLabels; i++) {
        let randomIndex = randomInteger(0, selectLabelsFrom.length - 1)
        if (randomIndex > selectLabelsFrom.length) {
            continue
        } else {
            labelsArr.push(selectLabelsFrom[randomIndex])
            selectLabelsFrom.splice(randomIndex, 1)
        }
    }
    return labelsArr
}


function seedHunderedTempData(totalData) {
    console.log("seeding data...", totalData)
    let seedDataArr = []
    for (let i = 0; i < totalData; i++) {
        let newAssetObj = {
            id: faker.random.uuid(),
            name: faker.company.companyName(),
            category: category[randomInteger(0, 3)],
            incomeFromAsset: randomInteger(1000, 100000),
            sqFootArea: randomInteger(100, 1000),
            labels: getLabels()
        }
        seedDataArr.push(newAssetObj)
        // console.log(newAssetObj)
    }

    return seedDataArr

}

// seedHunderedTempData(10)
export {
    seedHunderedTempData,
    category,
    labels
} 